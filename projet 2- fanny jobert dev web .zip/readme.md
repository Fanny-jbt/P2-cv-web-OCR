Description du projet :

Projet 2 parcours dev web oppenclassroom

lien vers git hub page  https://lliolla.github.io/P2-cv-web/

intitulé :
Transformez votre CV en site Web : selon une maquette fournie pour l'exercise et en pensant la page en responsive.
 